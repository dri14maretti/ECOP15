import javax.swing.*;

public class App {
    public static void main(String[] args) throws Exception {
        Pascal trianguloDePascal = new Pascal();

        trianguloDePascal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
