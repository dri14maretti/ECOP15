import javax.swing.JFrame;

public class App {
    public static void main(String[] args) throws Exception {
        Dados dados = new Dados();
        dados.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
