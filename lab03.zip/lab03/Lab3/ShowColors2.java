// Fig. 15.8: ShowColors2.java
// Choosing colors with JColorChooser.
package javaapplication3;
import javax.swing.JFrame;

public class ShowColors2 {
    // execute application

    public static void main(String[] args) {
        ShowColors2JFrame application = new ShowColors2JFrame();
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    } // end main
} // end class ShowColors2